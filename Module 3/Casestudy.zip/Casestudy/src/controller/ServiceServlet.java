package controller;

import bean.service.Service;
import service.IServiceSvc;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "ServiceServlet", value = "/service")
public class ServiceServlet extends HttpServlet {
    IServiceSvc service;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            action = "";
        }

        switch (action) {
            case "create":
                showCreateForm(request, response);
                break;
            default:
                showListServices(request, response);
                break;
        }
    }

    private void showListServices(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Service> list = service.readAllServices();

        request.setAttribute("listService", list);
        request.getRequestDispatcher("service/list-service.jsp").forward(request, response);
    }

    private void createService(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        int area = Integer.parseInt(request.getParameter("area"));
        double cost = Double.parseDouble(request.getParameter("cost"));
        int numberOfPeople = Integer.parseInt(request.getParameter("maxPeople"));
        int rentTypeId = Integer.parseInt(request.getParameter("rentType"));
        int serviceTypeId = Integer.parseInt(request.getParameter("serviceType"));
        String standard = request.getParameter("standard");
        String description = request.getParameter("description");
        double poolArea = Double.parseDouble(request.getParameter("poolArea"));
        int numberOfFloors = Integer.parseInt(request.getParameter("numberOfFloors"));

        int id = service.addService(name, area, cost, numberOfPeople, rentTypeId, serviceTypeId, standard, description, poolArea, numberOfFloors);

        request.setAttribute("newServiceId", id);
        request.setAttribute("message", "Add Successfully!");
        showListServices(request, response);
    }

    private void showCreateForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.getRequestDispatcher("service/add-service.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            action = "";
        }

        switch (action) {
            case "create":
                createService(request, response);
                break;
            default:
                break;
        }
    }
}
