package repository.impl;

import bean.service.RentType;
import bean.service.Service;
import bean.service.ServiceType;
import repository.IServiceRepo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static util.DBContext.getConnection;

public class ServiceRepo implements IServiceRepo {
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    @Override
    public int addService(String name, int area, double cost, int maxNumberOfPeople, int rentTypeId, int serviceTypeId, String standardRoom, String descriptionConvenience, double poolArea, int numberOfFloor) {
        String INSERT_SERVICE = "INSERT INTO service (" +
                "service_name, " +
                "service_area, " +
                "service_cost, " +
                "service_max_people, " +
                "rent_type_id, " +
                "service_type_id, " +
                "standard_room, " +
                "description_other_convenience, " +
                "pool_area, " +
                "number_of_floors) " +
                "VALUES (?,?,?,?,?,?,?,?,?,?);";

        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(INSERT_SERVICE, Statement.RETURN_GENERATED_KEYS);

            pstmt.setString(1, name);
            pstmt.setInt(2, area);
            pstmt.setDouble(3, cost);
            pstmt.setInt(4, maxNumberOfPeople);
            pstmt.setInt(5, rentTypeId);
            pstmt.setInt(6, serviceTypeId);
            pstmt.setString(7, standardRoom);
            pstmt.setString(8, descriptionConvenience);
            pstmt.setDouble(9, poolArea);
            pstmt.setInt(10, numberOfFloor);

            pstmt.executeUpdate();

            rs = pstmt.getGeneratedKeys();
            System.out.println(pstmt);

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
                pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return 0;
    }

    @Override
    public List<Service> readAllServices() {
        List<Service> list = new ArrayList<>();

        String SELECT_ALL_SERVICES = "";

        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(SELECT_ALL_SERVICES);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                list.add(new Service(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getInt(3),
                        rs.getDouble(4),
                        rs.getInt(5),
                        getRentTypeById(rs.getInt(6)),
                        getServiceTypeById(rs.getInt(7)),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getDouble(10),
                        rs.getInt(11)
                ));
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                conn.close();
                pstmt.close();
                rs.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }

        return list;
    }

    public RentType getRentTypeById(int id) {
        String SELECT_RENT_TYPE_BY_ID = "SELECT * FROM rent_type WHERE rent_type_id = ?";

        try {
            Connection connection = getConnection();
            PreparedStatement preparedStatement = conn.prepareStatement(SELECT_RENT_TYPE_BY_ID);
            preparedStatement.setInt(1, id);
            ResultSet resultSet = pstmt.executeQuery();


        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    public ServiceType getServiceTypeById(int id) {

        return null;
    }
}
