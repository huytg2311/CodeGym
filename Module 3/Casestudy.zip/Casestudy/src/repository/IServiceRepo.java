package repository;

import bean.service.Service;

import java.util.List;

public interface IServiceRepo {

    int addService(
            String name,
            int area,
            double cost,
            int maxNumberOfPeople,
            int rentTypeId,
            int serviceTypeId,
            String standardRoom,
            String descriptionConvenience,
            double poolArea,
            int numberOfFloor
    );

    List<Service> readAllServices();
}
